/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.sf.zwrath_tracker;

/**
 *
 * @author dhruv
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.event.ActionListener;
import java.io.*;
import java.sql.*;
import javax.swing.JOptionPane;
import java.util.*;
import java.text.*;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import java.awt.*;
import java.awt.event.*;

class Student extends JFrame
{
JFrame f;
JLabel l1,l2,l3,l4,l5,l6,l7,l8;
JTextField t1,t2,t3,t4,t5,t6,t7,t8;
JButton b1,b2,b3,b4,b5,b6;
ResultSet rs,rs2;
Statement smt;
PreparedStatement smt1,smt2,smt3;
Connection con;
int i;

Student()
{
	
//Frame Settings
f=new JFrame();
f.setTitle("Student");
f.setLayout(null);
f.setVisible(true);
f.setSize(470,330);
f.setLocation(400,300);

f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
f.addWindowListener(new java.awt.event.WindowAdapter() {
    @Override
    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
        if (JOptionPane.showConfirmDialog(f, 
            "Are you sure to close this window?", "Really Closing?", 
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION){
		//	new StudentHome();
           // f.setVisible(false);
        }
    }
});

//Labels
l1 = new JLabel("Roll NO:");
l1.setBounds(10,20,100,25);
l1.setForeground(Color.BLUE);
f.add(l1);
l2=new JLabel("Name:");
l2.setBounds(10,50,100,25);
l2.setForeground(Color.BLUE);
f.add(l2);
l3 = new JLabel("Father's Name:");
l3.setBounds(10,80,100,25);
l3.setForeground(Color.BLUE);
f.add(l3);
l4=new JLabel("Phone No:");
l4.setBounds(10,110,100,25);
l4.setForeground(Color.BLUE);
f.add(l4);
l5 = new JLabel("Address:");
l5.setBounds(10,140,100,25);
l5.setForeground(Color.BLUE);
f.add(l5);
l6=new JLabel("Class:");
l6.setBounds(10,170,100,25);
l6.setForeground(Color.BLUE);
f.add(l6);
l7=new JLabel("Date Of Birth:");
l7.setBounds(10,200,100,25);
l7.setForeground(Color.BLUE);
f.add(l7);

//TextFields
t1 = new JTextField();
t1.setBounds(120,20,220,25);
t1.addFocusListener(new FocusListener()
        {
            @Override
            public void focusGained(FocusEvent fe)
            {
				t1.setBackground(new Color(0,255,255));
                t1.setForeground(Color.BLACK);
            }

            @Override
            public void focusLost(FocusEvent fe)
            {
				try
				{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","SYSTEM","sharma");  
				smt=con.createStatement();
				rs=smt.executeQuery("SELECT * FROM student");
				while(rs.next())
				{
					if(t1.getText().equals(rs.getString(1)))
					{
						i=1;
						break;			
					}
				}
					if(i==1)
					{
					t1.setText(rs.getString(1));
					t2.setText(rs.getString(2));
					t3.setText(rs.getString(3));
					t4.setText(rs.getString(4));
					t5.setText(rs.getString(5));
					t6.setText(rs.getString(6));
					t7.setText(rs.getString(7));
					}else
					{
					JOptionPane.showMessageDialog(null,"Data Not Found");
					}
				}
				catch(Exception ex)
				{
					System.out.println(ex);
				}
				
			/* 	t1.setBounds(5,10,130,20);
				t1.setBackground(Color.WHITE);
                t1.setForeground(Color.BLACK); */
            }
        });	
f.add(t1);
t2 = new JTextField();
t2.setBounds(120,50,220,25);
f.add(t2);
t3 = new JTextField();
t3.setBounds(120,80,220,25);
f.add(t3);
t4 = new JTextField();
t4.setBounds(120,110,220,25);
f.add(t4);
t5 = new JTextField();
t5.setBounds(120,140,220,25);
f.add(t5);
t6 = new JTextField();
t6.setBounds(120,170,220,25);
f.add(t6);
t7 = new JTextField();
t7.setBounds(120,200,220,25);
f.add(t7);

//Buttons
b1= new JButton("Search");
b1.setBounds(10,240,80,30);
b1.addActionListener(new ActionListener() {
	@Override
	public void actionPerformed(ActionEvent e) {
	Object o = e.getSource();
	if(o==b1)
	{
	try
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","SYSTEM","sharma");  
		smt=con.createStatement();
		rs=smt.executeQuery("SELECT * FROM student");
	while(rs.next())
	{

		if(t1.getText().equals(rs.getString(1)))
		{
			i=1;
			break;			
		}
	}
		if(i==1)
		{
				t1.setText(rs.getString(1));
				t2.setText(rs.getString(2));
				t3.setText(rs.getString(3));
				t4.setText(rs.getString(4));
				t5.setText(rs.getString(5));
				t6.setText(rs.getString(6));
				t7.setText(rs.getString(7));
		}else
		{
		JOptionPane.showMessageDialog(null,"Data Not Found");
		}
	}
	catch(Exception ex)
	{
		System.out.println(ex);
	}
	}	
	}
	});
f.add(b1);


b2= new JButton("Insert");
b2.setBounds(100,240,80,30);
b2.addActionListener(new ActionListener() {
	@Override
	public void actionPerformed(ActionEvent e) {
	Object o = e.getSource();
	if(o==b2)
	{
	try
	{
		//Class.forName("oracle.jdbc.driver.OracleDriver");
		//con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","SYSTEM","sharma");  
		smt1=con.prepareStatement("insert into Student values(?,?,?,?,?,?,?)");
		int ch=JOptionPane.showConfirmDialog(null,"Do You Want to Save this Data ?","Confirm",JOptionPane.YES_NO_OPTION);
		
		if(ch==0)
		{
			smt1.setString(1,t1.getText());
			smt1.setString(2,t2.getText());
			smt1.setString(3,t3.getText());
			smt1.setString(4,t4.getText());
			smt1.setString(5,t5.getText());
			smt1.setString(6,t6.getText());
			smt1.setString(7,t7.getText());
			smt1.executeUpdate();
			JOptionPane.showMessageDialog(null,"Data Has Been Saved.");
		}
	}
	catch(Exception ex)
	{
		System.out.println(ex);
	}
	}	
	}
	});
f.add(b2);

b3 = new JButton("Update");
b3.setBounds(190,240,80,30);
b3.addActionListener(new ActionListener() {
	@Override
	
	public void actionPerformed(ActionEvent e) {
	Object o = e.getSource();
	if(o==b3)
	{
	try
	{
		//Class.forName("oracle.jdbc.driver.OracleDriver");
		//con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","SYSTEM","");  
		smt2=con.prepareStatement("Update Student set RollNo=?,Name=?,Fathers_Name=?,PhoneNo=?,Address=?,Class=?,DateOfBirth=? where RollNo=?");
		int ch=JOptionPane.showConfirmDialog(null,"Do You Want to Update this Data ?","Confirm",JOptionPane.YES_NO_OPTION);
	
		if(ch==0)
		{		
			smt2.setString(8,t1.getText());
			smt2.setString(1,t1.getText());
			smt2.setString(2,t2.getText());
			smt2.setString(3,t3.getText());
			smt2.setString(4,t4.getText());
			smt2.setString(5,t5.getText());
			smt2.setString(6,t6.getText());
			smt2.setString(7,t7.getText());
			smt2.executeUpdate();
			JOptionPane.showMessageDialog(null,"Data Has Been Updated.");
		}
	}
	catch(Exception ex)
	{
		System.out.println(ex);
	}
	}	
	}
	});

f.add(b3);



b4= new JButton("Clear");
b4.setBounds(280,240,80,30);
b4.addActionListener(new ActionListener() {
	@Override
	public void actionPerformed(ActionEvent e) {
	t1.setText("");
	t2.setText("");
	t3.setText("");
	t4.setText("");
	t5.setText("");
	t6.setText("");
	t7.setText("");
	}
});
f.add(b4);

b6 = new JButton("Del");
b6.setBounds(370,240,70,30);
b6.addActionListener(new ActionListener() {
	@Override
	public void actionPerformed(ActionEvent e) {
	Object o = e.getSource();
	if(o==b6)
	{
	try
	{
		//Class.forName("oracle.jdbc.driver.OracleDriver");
		//con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","SYSTEM","sharma");  
		smt1=con.prepareStatement("Delete  from Student where RollNo=?");
		smt1.setString(1,t1.getText());
					int rowsDeleted = smt1.executeUpdate();
			if (rowsDeleted > 0) {
				JOptionPane.showMessageDialog(null,"Student Record Deleted Successfully From Anime History!");
				System.out.println("Student Record Deleted Successfully From Anime History!");
			}
			
	}
	catch(Exception ex)
	{
		System.out.println(ex);
	}
	}	
	}
	});
f.add(b6);
}
public static void main(String arr[])
{
new Student();
}
}

