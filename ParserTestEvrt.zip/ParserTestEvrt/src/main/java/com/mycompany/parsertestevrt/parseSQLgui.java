/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.parsertestevrt;

/**
 *
 * @author akash
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.event.ActionListener;
import java.io.*;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import java.beans.Statement;
import java.io.StringReader;
import net.sf.jsqlparser.*;
import net.sf.jsqlparser.parser.*;
import net.sf.jsqlparser.JSQLParserException;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.schema.Table;
//import net.sf.jsqlparser.statement.Statement;
import net.sf.jsqlparser.statement.insert.Insert;
import net.sf.jsqlparser.statement.select.*;
import net.sf.jsqlparser.util.SelectUtils;
import java.util.List;
import net.sf.jsqlparser.expression.Function;


public class parseSQLgui extends JFrame
{
    JFrame f;
    JLabel l1,l2,l3;
    JTextField t1,t2;
    JTextArea ta; 
    JScrollPane sbrText;
    JButton b1;
    parseSQLgui()
    {
        f=new JFrame();
        f.setTitle("Student");
        f.setLayout(null);
        f.setVisible(true);
        f.setSize(470,330);
        f.setLocation(400,300);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
f.addWindowListener(new java.awt.event.WindowAdapter() {
    @Override
    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
        if (JOptionPane.showConfirmDialog(f, 
            "Are you sure to close this window?", "Really Closing?", 
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION){
		//	new StudentHome();
           // f.setVisible(false);
        }
    }
});
        
        l1 = new JLabel("Query:");
        l1.setBounds(10,20,100,25);
        l1.setForeground(Color.BLUE);
        f.add(l1);
        l2=new JLabel("Expression:");
        l2.setBounds(10,50,100,25);
        l2.setForeground(Color.BLUE);
        f.add(l2);
    }
}
