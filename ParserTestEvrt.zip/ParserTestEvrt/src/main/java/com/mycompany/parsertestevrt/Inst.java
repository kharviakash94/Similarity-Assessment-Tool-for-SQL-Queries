/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.parsertestevrt;

/**
 *
 * @author akash
 */
import net.sf.jsqlparser.JSQLParserException;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.schema.Table;
import net.sf.jsqlparser.statement.insert.Insert;
import net.sf.jsqlparser.statement.select.*;

public class Inst {

    public static void main(String[] args) throws JSQLParserException {

        System.out.println("Program to parse INSERT sql statement");
        String insertSQL = "Insert into TargetTable " +
                "select col1, col2, col3 from SourceTable";

        try {
            Insert insertObj = (Insert) CCJSqlParserUtil.parse(insertSQL);

            System.out.println("Original Insert SQL details");
            System.out.println("---------------------------");
            System.out.println("Target Database: " + insertObj.getTable().getSchemaName());
            System.out.println("Target Table: " + insertObj.getTable().getName());
            System.out.println("Select statement of insert: " + insertObj.getSelect().getSelectBody().toString());

            //Modifying the target table details
            Table newTable = new Table();

            newTable.setName("NewTargetTable");
            newTable.setSchemaName("NewDatabase");
            insertObj.setTable(newTable);
            System.out.println("Full insert query:");
            System.out.println(insertObj.toString());

            System.out.println("\nModified Insert SQL details");
            System.out.println("---------------------------");
            System.out.println("Target Database: " + insertObj.getTable().getSchemaName());
            System.out.println("Target Table: " + insertObj.getTable().getName());
            System.out.println("Select statement of insert: " + insertObj.getSelect().toString());


            //Modifying the source table for select in insert
            PlainSelect selectBody = (PlainSelect) insertObj.getSelect().getSelectBody();
            ((Table) selectBody.getFromItem()).setName("NewSourceTable");
            ((Table) selectBody.getFromItem()).setSchemaName("NewDatabase");

            Select newSelect = new Select();
            newSelect.setSelectBody(selectBody);
            insertObj.setSelect(newSelect);
            System.out.println("Modified Select statement of insert: " + insertObj.getSelect().toString());
            System.out.println("Full insert query:");
            System.out.println(insertObj.toString());
            System.out.println("Parsing Mark: 0.8");
        } catch (JSQLParserException e) {
            e.printStackTrace();
            System.out.println("Parsing Mark: 0");
        }

    }
}