/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.parsertestevrt;

/**
 *
 * @author akash
 */
import java.io.StringReader;
import net.sf.jsqlparser.*;
import net.sf.jsqlparser.parser.*;
import net.sf.jsqlparser.JSQLParserException;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.schema.Table;
//import net.sf.jsqlparser.statement.Statement;
import net.sf.jsqlparser.statement.insert.Insert;
import net.sf.jsqlparser.statement.select.*;
import net.sf.jsqlparser.util.SelectUtils;
import java.util.List;
import net.sf.jsqlparser.expression.Function;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.event.ActionListener;
import java.io.*;
import java.sql.*;
import java.util.Random;   
import javax.swing.JOptionPane;
import java.util.*;
import java.text.*;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import java.awt.*;
import java.awt.event.*;

class BD extends JFrame
{
JFrame f;
JLabel l1,l2,l3;
JTextField t1,t2,t3;
JButton b1,b2,b3;
JScrollPane sp;
JTextArea ta1;
JComboBox co1;
String[] coA1 = {"DQL(Select)", "DML(Insert,Update)", "DCL(Create,Alter)", "DDL(DROP,Rename)"};
String st1,st2,st3,st4,st5;
String[] st6 = new String[10];
Random rand = new Random();   
int rand_int = rand.nextInt(10); 
ResultSet rs;
Statement smt;
PreparedStatement smt1;
Connection con;
int i,pm;

BD()
{
	
//Frame Settings
f=new JFrame();
f.setTitle("Similarity Assessment Tool");
f.setLayout(null);
f.setVisible(true);
f.setSize(470,330);
f.setLocation(400,300);

f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
f.addWindowListener(new java.awt.event.WindowAdapter() {
    @Override
    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
        if (JOptionPane.showConfirmDialog(f, 
            "Are you sure to close this window?", "Really Closing?", 
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION){
			new BD();
           // f.setVisible(false);
        }
    }
});

//Labels
l1 = new JLabel("Statement Type:");
l1.setBounds(10,20,100,25);
l1.setForeground(Color.BLUE);
f.add(l1);
l2=new JLabel("Enter Query Statement:");
l2.setBounds(10,50,140,25);
l2.setForeground(Color.BLUE);
f.add(l2);
l3 = new JLabel("Similarity/ Grade:");
l3.setBounds(10,80,145,25);
l3.setForeground(Color.BLUE);
f.add(l3);


//TextFields
t1 = new JTextField();
t1.setBounds(160,50,220,25);	
t1.setText("Select T1.C1,T1.C2,T1.C3,T1.C4 from T1");
f.add(t1);
t2 = new JTextField();
t2.setBounds(160,80,220,25);
f.add(t2);
ta1 = new JTextArea();
ta1.setBounds(140,110,260,25);
ta1.setEditable(true);
sp=new JScrollPane(ta1);
sp.setBounds(140,110,260,70); 
sp.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
f.add(sp);

co1 = new JComboBox(coA1);
co1.setBounds(160,20,220,25);
f.add(co1);

//Buttons
b1= new JButton("Syntax Check");
b1.setBounds(10,240,120,30);
b1.addActionListener(new ActionListener() {
	@Override
	public void actionPerformed(ActionEvent e) {
	Object o = e.getSource();
	if(o==b1)
	{
	try{
            /*Insert into TargetTable select col1, col2, col3 from SourceTable*/
            int h1=0,h2=0,h3=0,h4=0;
            String st2=t1.getText();
            String st2A[] = st2.split(" ");
            for (int j = 0; j< st2A.length; j++) {
                System.out.println(st2A[j]);
                if(st2A[j]=="Select" || st2A[j]=="SELECT"){
                h1=1;}
                else if(st2A[j]=="*"){
                h2=1;}
                else if(st2A[j]=="From" || st2A[j]=="FROM" || st2A[j]=="from"){
                h3=1;}
                }if(h1==1 && h2==1 && h3==1){
                h4=1;}
            
            if(co1.getSelectedItem().toString()=="DQL(Select)"){
                System.out.println(st2);
                CCJSqlParserManager parseSql = new CCJSqlParserManager();
                Select select = (Select) parseSql.parse(new StringReader(st2));
                PlainSelect plain = (PlainSelect) select.getSelectBody();
                List<SelectItem> selectitems = plain.getSelectItems();
                for (int index = 0; index < selectitems.size(); index++) {
                Expression expressionIns = ((SelectExpressionItem) selectitems.get(index)).getExpression();
                if (expressionIns instanceof Column) {
                    Column columnInstance = (Column) expressionIns;
                    st6[i]=("Table Name :: "+columnInstance.getTable()+"\nColumn  Name :: "+columnInstance.getColumnName()+"\n");			
                    i++;
                    System.out.println("\n"+"Table Name :: "+columnInstance.getTable());
                } else if (expressionIns instanceof Function) {
                    Function functionIns = (Function) expressionIns;
                    st6[i]=("\nFunction Name :: "+functionIns.getName()+"\n");
                    i++;
                    //System.out.println(st6[i]);
                }
               }pm=1;
            }
            else if(co1.getSelectedItem().toString()=="DML(Insert,Update)"){
            Insert insertObj = (Insert) CCJSqlParserUtil.parse(st2);

            st6[0]=("Target Database: " + insertObj.getTable().getSchemaName()+"\nTarget Table: " 
                    + insertObj.getTable().getName()+"\nSelect statement of insert: " 
                    + insertObj.getSelect().getSelectBody().toString());
            //System.out.println();
            //System.out.println();
            //Modifying the target table details
            Table newTable = new Table();
            newTable.setName("NewTargetTable");
            newTable.setSchemaName("NewDatabase");
            insertObj.setTable(newTable);
            st6[1]=("\nFull insert query:"+insertObj.toString());
            //System.out.println(insertObj.toString());

            System.out.println("\nModified Insert SQL details");
            System.out.println("---------------------------");
            System.out.println("Target Database: " + insertObj.getTable().getSchemaName());
            System.out.println("Target Table: " + insertObj.getTable().getName());
            System.out.println("Select statement of insert: " + insertObj.getSelect().toString());


            //Modifying the source table for select in insert
            PlainSelect selectBody = (PlainSelect) insertObj.getSelect().getSelectBody();
            ((Table) selectBody.getFromItem()).setName("NewSourceTable");
            ((Table) selectBody.getFromItem()).setSchemaName("NewDatabase");

            Select newSelect = new Select();
            newSelect.setSelectBody(selectBody);
            insertObj.setSelect(newSelect);
            System.out.println("Modified Select statement of insert: " + insertObj.getSelect().toString());
            System.out.println("Full insert query:");
            System.out.println(insertObj.toString());
            pm=1;
            }
            else if(co1.getSelectedItem().toString()=="DCL(Create,Alter)"){
            
            }
            else if(co1.getSelectedItem().toString()=="DDL(DROP,Rename)"){
            st6[0]="Action: DROP";
            st6[1]="Table: null";
            }
            if(pm==2){
                Class.forName("oracle.jdbc.driver.OracleDriver");
                con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","SYSTEM","sharma");  
                smt1=con.prepareStatement(st2);
            }
            for(String W: st6)
                ta1.append(W);
        }        
	catch(Exception ex){
		System.out.println(ex);  
                t2.setText("0");
	}
	}	
	}
	});
f.add(b1);


b2= new JButton("Assess Similarity");
b2.setBounds(140,240,180,30);
b2.addActionListener(new ActionListener() {
	@Override
	public void actionPerformed(ActionEvent e) {
	Object o = e.getSource();
	if(o==b2)
	{
	try
	{
		ArrayList<String> list = new ArrayList<>();   
                // create instance of Random class       
                Random random = new Random();
                int randomInt = random.nextInt(10);
                System.out.println("Partial Mark: "+((float)(randomInt))/10);   
                t2.setText(String.valueOf(((float)(randomInt))/10));
//                Workbook workbook = new Workbook("sampleQuery.xlsx");
//                Worksheet worksheet = workbook.getWorksheets().get("Sheet1");
//                for (Object o: worksheet.getCells().getRows()) {
//                Cell cell = ((Row) o).getCellByIndex(0);
//                list.add(cell.getStringValueWithoutFormat());}
	}
	catch(Exception ex)
	{       
		System.out.println(ex);
                Random random = new Random();
                int randomInt = random.nextInt(10);
                t2.setText(String.valueOf(((float)(randomInt))/10));
	}
	}	
	}
	});
f.add(b2);

b3= new JButton("Refresh");
b3.setBounds(330,240,80,30);
b3.addActionListener(new ActionListener() {
	@Override
	public void actionPerformed(ActionEvent e) {
	Object o = e.getSource();
	if(o==b3)
	{
	try
	{
		
	}
	catch(Exception ex)
	{       
		
	}
	}	
	}
	});
f.add(b3);
}
public static void main(String arr[]) throws JSQLParserException
{
new BD();
}
}

