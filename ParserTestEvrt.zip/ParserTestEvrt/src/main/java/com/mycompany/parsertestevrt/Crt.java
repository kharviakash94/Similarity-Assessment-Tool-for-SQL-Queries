/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.parsertestevrt;

/**
 *
 * @author akash
 */
import net.sf.jsqlparser.JSQLParserException;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.schema.Table;
import net.sf.jsqlparser.statement.Statement;
import net.sf.jsqlparser.statement.create.table.ColDataType;
import net.sf.jsqlparser.statement.create.table.ColumnDefinition;
import net.sf.jsqlparser.statement.create.table.CreateTable;
import net.sf.jsqlparser.statement.insert.Insert;
import net.sf.jsqlparser.statement.select.*;
import net.sf.jsqlparser.util.SelectUtils;

import java.util.ArrayList;
import java.util.List;

public class Crt {

    public static void main(String[] args) {


        System.out.println("Program to parse CREATE sql statement");
        System.out.println("-------------------------------------");
        String createSQL = "CREATE Table AIR.Flyer (" +
                "id INTEGER NOT NULL," +
                "name varchar(100) NOT NULL," +
                "CRE_TS TIMESTAMP(0) NOT NULL," +
                "UPD_TS TIMESTAMP(0) NOT NULL" +
                ")" ;
        String drp= "DROP Flyer";

        try {
            Statement createTable =  CCJSqlParserUtil.parse(createSQL);

            System.out.println("Table Name from query: " + ((CreateTable) createTable).getTable().getName());
            System.out.println("Database Name from query: " + ((CreateTable) createTable).getTable().getSchemaName());
            String sqlTableName = ((CreateTable) createTable).getTable().getName();
            System.out.println("Columns in the given insert query");
            System.out.println("---------------------------------");
            for(ColumnDefinition col: ((CreateTable) createTable).getColumnDefinitions())
            {
                System.out.println(col.getColumnName() + " - " + col.getColDataType().toString());
            }

            //Modifying the tablename and DB
            ((CreateTable) createTable).getTable().setName("NewTable");
            ((CreateTable) createTable).getTable().setSchemaName("NewDatabase");


            //Adding a new column to the create statement
            ColumnDefinition newCol = new ColumnDefinition();
            newCol.setColumnName("processDate");
            ColDataType colDataType = new ColDataType();
            colDataType.setDataType("DATE");
            newCol.setColDataType(colDataType);
            List<String> colSpecStrings = new ArrayList<>();
            colSpecStrings.add("FORMAT 'YYYY-MM-DD' NOT NULL DEFAULT DATE '1970-01-01'");
            //newCol.setColumnSpecStrings(colSpecStrings);
            //((CreateTable) createTable).getColumnDefinitions().add(newCol);


            String newSql = createTable.toString();
            System.out.println("\nNew Create statement:");
            System.out.println("-----------------------");
            System.out.println(newSql);
            System.out.println("New Columns");
            System.out.println("-----------");
            for(ColumnDefinition col: ((CreateTable) createTable).getColumnDefinitions())
            {
                System.out.println(col.getColumnName() + " - " + col.getColDataType().toString());
            }
            System.out.println("Parsing Mark: 1");
        } catch (JSQLParserException e) {
            e.printStackTrace();
            System.out.println("Parsing Mark: 0");
        }

    }
}
