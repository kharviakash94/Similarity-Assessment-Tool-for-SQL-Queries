/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.parsertestevrt;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.event.ActionListener;
import java.io.*;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import java.beans.Statement;
import java.io.StringReader;
import net.sf.jsqlparser.*;
import net.sf.jsqlparser.parser.*;
import net.sf.jsqlparser.JSQLParserException;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.schema.Table;
//import net.sf.jsqlparser.statement.Statement;
import net.sf.jsqlparser.statement.insert.Insert;
import net.sf.jsqlparser.statement.select.*;
import net.sf.jsqlparser.util.SelectUtils;
import java.util.List;
import net.sf.jsqlparser.expression.Function;
/**
 *
 * @author akash
 */
public class TryParser {
    public static void main(String[] args) throws JSQLParserException{
    //String q1="SELECT c.name,c.address,c.joining_date FROM customer c";
    //String q2="SELECT DISTINCT(c.name) FROM Customer c";// in coco";
    String q1 ="SELECT Cs.Country, Cs.Name, Cs.ID FROM Cs ORDER BY Cs.Name";
    String q3 ="UPDATE Student SET NAME = 'PRATIK' WHERE Age = 20;";
    String q4 ="INSERT INTO mytable (col1, col2, col3) VALUES (?, 'sadfsd', 234)";
    CCJSqlParserManager sqlParser = new CCJSqlParserManager();
    
    String statement;
        try {
            CCJSqlParserManager parseSql = new CCJSqlParserManager();
            Insert insert = (Insert)CCJSqlParserUtil.parse(q1);
            System.out.println(insert.toString());
            System.out.println("Parsing Mark:");
        } catch (JSQLParserException exceptionInstance) {
            exceptionInstance.printStackTrace();
            System.out.println("Parsing Mark:");
        }
     /*System.out.println("Program to parse SELECT sql statement");
        String selectSQL = "Select id, name, location from Database.UserTable " +
                "where created_dt >= current_date- 180";
        try {
            Statement select = (Statement) CCJSqlParserUtil.parse(selectSQL);
            //Simple Select query parsing
            System.out.println("Simple single select with where condition\n");
            System.out.println("List of  columns in select query");
            System.out.println("--------------------------------");
            List<SelectItem> selectCols = ((PlainSelect) ((Select) select).getSelectBody()).getSelectItems();
            for (SelectItem selectItem : selectCols)
                System.out.println(selectItem.toString());
            System.out.println("Where condition: " + ((PlainSelect) ((Select) select).getSelectBody()).getWhere().toString());
            SelectUtils.addExpression((Select) select, new Column("newColumnName"));
            System.out.println("\nModified select with additional column");
            System.out.println("----------------------------------");
            System.out.println(select.toString());
            ((Table) ((PlainSelect) ((Select) select).getSelectBody()).getFromItem()).setName("NewSourceTable");
            ((Table) ((PlainSelect) ((Select) select).getSelectBody()).getFromItem()).setSchemaName("NewSourceTable");
            System.out.println("\nModified select with new table and database");
            System.out.println("-------------------------------------");
            System.out.println(select.toString());
            selectSQL = "Select w.id, w.name, w.location from Database.WebLogs w " +
                    "union Select m.id, m.name, m.location from Database.MobileLogs m ";
            Statement newSQL = (Statement) CCJSqlParserUtil.parse(selectSQL);
            List<SelectBody> selectList = ((SetOperationList) ((Select) newSQL).getSelectBody()).getSelects();
            System.out.println("\nListing all selects from the query");
            System.out.println("----------------------------------");
            for (SelectBody selectBody : selectList)
                System.out.println(selectBody.toString());
        } catch (JSQLParserException e) {
            e.printStackTrace();
        }*/
    
}
}
